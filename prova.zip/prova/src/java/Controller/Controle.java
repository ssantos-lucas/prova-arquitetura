/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Funcionario;
import Model.FuncionarioDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author lucas
 */
@WebServlet(name = "Controle", urlPatterns = {"/Controle"})
public class Controle extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String flag, mensagem = null;
        flag = request.getParameter("flag");

        if (flag.equalsIgnoreCase("salvar")) {
            Funcionario func = new Funcionario();
            func.setMatricula(request.getParameter("matriculaFuncionario"));
            func.setNome(request.getParameter("nomeFuncionario"));
            func.setCargo(request.getParameter("cargoFuncionario"));
            func.setIdade(Integer.parseInt(request.getParameter("idadeFuncionario")));
            func.setSalario(Double.parseDouble(request.getParameter("salarioFuncionario")));

            int resultado = new FuncionarioDAO().salvarFuncionario(func);
            switch (resultado) {
                case 1:
                    mensagem = "Funcionario salvo com sucesso.";
                    break;
                case 2:
                    mensagem = "Funcionario já cadastrado.";
                    break;
                case 3:
                    mensagem = "Erro ao cadastrar o Funcionario, contate um administrador.";
                    break;
                default:
                    break;
            }
            request.setAttribute("m", mensagem);
            RequestDispatcher disp = request.getRequestDispatcher("Mensagem.jsp");
            disp.forward(request, response);
        } else if (flag.equalsIgnoreCase("listarFuncionario")) {
            List<Funcionario> funcionarios = new FuncionarioDAO().listarFuncionarios();
            request.setAttribute("listarFuncionarios", funcionarios);
            RequestDispatcher disp = request.getRequestDispatcher("ListarFuncionarios.jsp");
            disp.forward(request, response);
        } else if (flag.equalsIgnoreCase("consultar")) {
            String matricula = request.getParameter("matriculaFuncionario");
            FuncionarioDAO dao = new FuncionarioDAO();
            Funcionario func = dao.consultarFuncionario(matricula);
            if (func == null) {
                mensagem = "Produto não encontrado";
                request.setAttribute("m", mensagem);
                RequestDispatcher disp = request.getRequestDispatcher("Mensagem.jsp");
                disp.forward(request, response);
            } else {
                request.setAttribute("Funcionario", func);
                RequestDispatcher disp = request.getRequestDispatcher("consultar.jsp");
                disp.forward(request, response);
            }
        }
    }
}
