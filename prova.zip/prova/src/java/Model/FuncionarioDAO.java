/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

/**
 *
 * @author lucas
 */
public class FuncionarioDAO {

    private EntityManagerFactory conn;
    private EntityManager manager;

    public void conectar() {
        conn = Persistence.createEntityManagerFactory("provaPU");
        manager = conn.createEntityManager();
    }
    
        public int salvarFuncionario(Funcionario func) {
        conectar();
        try {
            manager.getTransaction().begin();
            manager.persist(func);
            manager.getTransaction().commit();
            return 1; // Departamento cadastrado
        } catch (RollbackException ex) {
            return 2; // Já cadastrado
        } catch (Exception ex) {
            return 3; //Deu qualquer outro erro
        }
    }
        
        public List<Funcionario> listarFuncionarios() {
        conectar();
        try {
            TypedQuery<Funcionario> query = manager.createNamedQuery("Funcionario.findAll", Funcionario.class);
            List<Funcionario> funcionarios = query.getResultList();
            return funcionarios;
        } catch (NoResultException ex) {
            return null;
        }
    }

    public Funcionario consultarFuncionario(String matricula) {
        conectar();
        try {
            TypedQuery queryId = manager.createNamedQuery("Funcionario.findByMatricula", Funcionario.class);
            queryId.setParameter("matriculaFuncionario", matricula);
            Funcionario func = (Funcionario) queryId.getSingleResult();
            return func;
        } catch (NoResultException ex) {
            return null;
        }
    }

    
    
}
